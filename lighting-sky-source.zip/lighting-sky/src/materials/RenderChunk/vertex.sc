$input a_color0, a_position, a_texcoord0, a_texcoord1
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2, i_data3
#endif
$output v_color0, v_color1, v_fog, v_refl, v_texcoord0, v_lightmapUV, v_extra

#include <bgfx_shader.sh>
#include <newb/main.sh>

uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogColor;
uniform vec4 TimeOfDay;
uniform vec4 CameraPosition;

SAMPLER2D_AUTOREG(s_MatTexture);
SAMPLER2D_AUTOREG(s_LightMapTexture);

void main() {
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, i_data3);
  #else
    mat4 model = u_model[0];
  #endif

  vec3 worldPos = mul(model, vec4(a_position, 1.0)).xyz;
  vec4 pos = mul(u_viewProj, vec4(worldPos, 1.0));

  #if !(defined(DEPTH_ONLY_OPAQUE) || defined(DEPTH_ONLY) || defined(INSTANCING))
    #ifdef RENDER_AS_BILLBOARDS
      vec4 color = vec4(1.0,1.0,1.0,1.0);
    #else
      vec4 color = a_color0;
    #endif

    float camDis = length(ViewPositionAndTime.xyz - worldPos);
    float relativeDist = camDis / FogAndDistanceControl.z + RenderChunkFogAlpha.x;

    vec2 uv0 = 2.0*a_texcoord0.xy;
    uv0 = fract(uv0) + ((floor(uv0)-0.5)/16384.0);
    vec2 uv1 = fract(a_texcoord1.y*vec2(256.0, 4096.0));
    vec2 lit = uv1*uv1;

    bool isColored = color.r != color.g || color.r != color.b;
    float shade = isColored ? color.g*1.5 : color.g;

    #if defined(ALPHA_TEST) && !defined(RENDER_AS_BILLBOARDS)
      bool isTree = (isColored && (fract(a_position.x)+fract(a_position.y)+fract(a_position.z) < 0.001)) || color.a == 0.0;
    #else
      bool isTree = false;
    #endif

    nl_environment env = nlDetectEnvironment(TimeOfDay.x, FogColor.rgb, FogAndDistanceControl.xyz);
    nl_skycolor skycol = nlSkyColors(env);
    highp float t = ViewPositionAndTime.w;

    #ifdef SEASONS
      isTree = true;
      color.w *= color.w;
      color = vec4(color.www, 1.0);
    #else
      if (isColored) {
        color.rgb *= color.rgb*1.2;
      }
    #endif

    // Newb lighting: sun/moon light + shadow, sky ambient, torch light
    vec3 torchColor;
    vec3 light = nlLighting(s_LightMapTexture, skycol, env, worldPos, torchColor, a_color0.rgb, uv1, lit, isTree, shade, t, FogAndDistanceControl.z, TimeOfDay.x, CameraPosition.xyz);

    color.rgb *= light;

    // extra fake shadow (from shadow-only v1): darken areas not exposed to sky
    if (!(env.nether || env.end || env.underwater)) {
      float nightIntensity = 1.0 - (0.5 + 0.5*env.dayFactor);
      nightIntensity *= nightIntensity;
      float k = 1.0 - NL_SHADOW_INTENSITY + 0.6*NL_SHADOW_INTENSITY*nightIntensity;
      float shadow = max(step(0.93, uv1.y), mix(k, 1.0, lit.y));
      shadow = max(shadow, lit.x); // keep torch-lit areas bright
      color.rgb *= shadow;
    }

    // fog uses the same sky colors as the Sky material
    vec3 viewDir = normalize(ViewPositionAndTime.xyz - worldPos);
    vec4 fog;
    fog.rgb = nlRenderSky(skycol, env, viewDir, t, true);
    fog.a = nlRenderFogFade(relativeDist, FogColor.rgb, FogAndDistanceControl.xy);
    if (env.nether) {
      fog.rgb = colorCorrectionInv(FogColor.rgb);
    }

    v_color0 = color;
    v_color1 = a_color0;
    v_fog = fog;
    v_refl = vec4(0.0,0.0,0.0,0.0);
    v_texcoord0 = uv0;
    v_lightmapUV = uv1;
    v_extra = vec4(shade, worldPos.y, 0.0, 1.0);
  #endif

  gl_Position = pos;
}
